from flask import Flask, render_template, request, redirect, url_for, session
import os
import pandas as pd
import zipfile
import tempfile

app = Flask(__name__)
app.secret_key = 'supersecretkey'
PASSWORD = 'kader11000'

# Helper to extract file contents
def extract_keywords(file):
    keywords = []
    temp_dir = tempfile.mkdtemp()
    filename = file.filename
    filepath = os.path.join(temp_dir, filename)
    file.save(filepath)

    if zipfile.is_zipfile(filepath):
        with zipfile.ZipFile(filepath, 'r') as zip_ref:
            zip_ref.extractall(temp_dir)
        for root, _, files in os.walk(temp_dir):
            for name in files:
                keywords += read_file(os.path.join(root, name))
    else:
        keywords += read_file(filepath)
    return keywords

def read_file(path):
    if path.endswith('.txt'):
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            return f.read().splitlines()
    elif path.endswith('.csv'):
        df = pd.read_csv(path)
        return df.iloc[:, 0].astype(str).tolist()
    elif path.endswith('.xlsx'):
        df = pd.read_excel(path)
        return df.iloc[:, 0].astype(str).tolist()
    return []

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST' and not session.get('authorized'):
        password = request.form.get('password')
        if password == PASSWORD:
            session['authorized'] = True
        else:
            return render_template('index.html', authorized=False, error="Incorrect password")

    return render_template('index.html', authorized=session.get('authorized', False))

@app.route('/scanner', methods=['POST'])
def scanner():
    if not session.get('authorized'):
        return redirect(url_for('index'))

    source = request.form.get('source')
    keyword = request.form.get('keyword', '')
    uploaded_file = request.files.get('file')
    keywords = []

    if source == 'api':
        keywords = [k.strip() for k in keyword.split(',') if k.strip()]
    elif source == 'local':
        keywords = [k.strip() for k in keyword.split(',') if k.strip()]
    elif source == 'file' and uploaded_file:
        keywords = extract_keywords(uploaded_file)

    # Simulated search results
    results = [f"[+] Found match: {k}@example.com" for k in keywords if k]
    return render_template('index.html', results=results, count=len(results), authorized=True)

if __name__ == '__main__':
    app.run(debug=True)
